# Camel-Up
Implementation of the board game Camel Up for teaching introductory statistics
